<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gamage Mills Heaven</title>
    <link rel="stylesheet" href="homelog1.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <!-- HomeLog Section -->
            <div class="Hlogswiper-slide container">
                <div class="HlogHome-text">
                    <h1>WELCOME!!<br> GAMAGE MILLS HEAVEN</h1>
                    <a href="log.php" class="btn">LOGIN</a>
                </div>
            </div>
        </div>
    </section>
</body>
</html>
